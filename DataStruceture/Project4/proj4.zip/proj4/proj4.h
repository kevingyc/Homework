Data* read_input_data(int &data_size);
void bubble_sort(Data data[] , int size);
void insertion_sort(Data data[] , int size);
void heap_sort(Data data[] , int size);
void quick_sort(Data data[] , int size);
void merge_sort(Data data[] , int size);